import { useState } from "react";
import axios from "axios";

function App() {
  const [mode, setMode] = useState("signals");
  const [email, setEmail] = useState("");
  const [id, setId] = useState("");
  const [asset, setAsset] = useState("EUR/USD");
  const [result, setResult] = useState("");

  const handleAction = async () => {
    const endpoint = mode === "signals" ? "/signal" : "/auto";
    const res = await axios.post("http://localhost:10000" + endpoint, {
      email,
      quotex_id: id,
      asset,
    });
    setResult(res.data.signal.toUpperCase());
  };

  return (
    <div className="p-4">
      <h1>BOT QUOTEX IA</h1>
      <input placeholder="Seu email" onChange={e => setEmail(e.target.value)} />
      <input placeholder="Seu ID Quotex" onChange={e => setId(e.target.value)} />
      <input placeholder="Ativo" onChange={e => setAsset(e.target.value)} />
      <button onClick={() => setMode("signals")}>Somente Sinais</button>
      <button onClick={() => setMode("auto")}>Automático</button>
      <button onClick={handleAction}>Executar</button>
      {result && <p>Resultado: {result}</p>}
    </div>
  );
}

export default App;
