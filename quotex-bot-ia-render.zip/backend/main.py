from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from services.signal_generator import generate_signal
from services.quotex_api import execute_trade
from models import TradeRequest

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.post("/signal")
def signal(request: TradeRequest):
    signal = generate_signal(request.asset)
    return {"signal": signal}

@app.post("/auto")
def auto(request: TradeRequest):
    signal = generate_signal(request.asset)
    result = execute_trade(request.email, request.quotex_id, request.asset, signal)
    return {"status": result, "signal": signal}
