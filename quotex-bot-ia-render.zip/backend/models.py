from pydantic import BaseModel

class TradeRequest(BaseModel):
    email: str
    quotex_id: str
    asset: str
