import random

def generate_signal(asset):
    # Exemplo: combinação entre IA + RSI + MACD (simulado)
    signals = ['call', 'put']
    return random.choice(signals)
