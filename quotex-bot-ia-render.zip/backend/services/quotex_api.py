def execute_trade(email, quotex_id, asset, signal):
    print(f"Enviando ordem {signal.upper()} para {asset} ({email}, ID: {quotex_id})")
    return "executado"
