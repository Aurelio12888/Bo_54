# Bot de IA para Quotex com Deploy no Render
